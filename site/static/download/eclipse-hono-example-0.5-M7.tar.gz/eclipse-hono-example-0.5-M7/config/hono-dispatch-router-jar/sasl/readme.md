# qdrouterd.sasldb

Contains 2 example users:

| username      | password   |
|---------------|------------|
| consumer@HONO | verysecret |
| user1@HONO    | pw         |
